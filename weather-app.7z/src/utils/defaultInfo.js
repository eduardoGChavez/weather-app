export const defaultUserList = [
  {
    id: "1",
    name: "Alejandro",
    latitude: "20.644860",
    longitude: "-103.319247",
  },
  {
    id: "2",
    name: "Mariana",
    latitude: "21.970957",
    longitude: "-105.271633",
  },
  {
    id: "3",
    name: "Sergio",
    latitude: "26.422085",
    longitude: "-99.758014",
  },
  {
    id: "4",
    name: "Armando",
    latitude: "17.755987",
    longitude: "-99.473025",
  },
  {
    id: "5",
    name: "Marco",
    latitude: "21.028566",
    longitude: "-100.955756",
  } 
]